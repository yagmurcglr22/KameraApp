﻿using System;
using System.Drawing;
using System.Windows.Forms;
using AForge.Video;
using AForge.Video.DirectShow;
using Microsoft.WindowsAPICodePack.Dialogs;
namespace camerasscs
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
            var vidDevs = new FilterInfoCollection(FilterCategory.VideoInputDevice);
            foreach (FilterInfo videoDevice2 in vidDevs)
            {
                CameraList.Items.Add(videoDevice2.Name);

            }



        }
        FilterInfo filterCa;
        IVideoSource videoSource;
        int frames;
        private void CameraList_SelectedIndexChanged(object sender, EventArgs e)
        {


            if (videoSource != null)
            {
                frames = 0;
                videoSource.Stop();
                videoSource = null;
            }
            var videvs = new FilterInfoCollection(FilterCategory.VideoInputDevice);
            filterCa = videvs[CameraList.SelectedIndex];
            //VideoInput videoInput =;


            videoSource = new VideoCaptureDevice(videvs[CameraList.SelectedIndex].MonikerString);

            videoSource.Start();
            if (videoSource != null) 
            {
                videoSource.NewFrame += new NewFrameEventHandler(NewFrameVoid);
                
            }
            //  videoSource.NewFrame += new NewFrameEventHandler(NewFrameVoid);

        }

        private void NewFrameVoid(object sender, NewFrameEventArgs e)
        {
            //add a way to enter desired size and then put an if statement here for default value

            System.Drawing.Image img = (Bitmap)e.Frame.Clone();



            //img = pictureBox2.Width;

            pictureBox1.Image = img;



            //pictureBox2.Image ;

        }
        string selectedpath;
        Bitmap imageOnClick;
        private void button1_Click(object sender, EventArgs e)
        {
            imageOnClick = (Bitmap)pictureBox1.Image;

            CommonOpenFileDialog dialog = new CommonOpenFileDialog();
             dialog.InitialDirectory = "C:\\Users";
             dialog.IsFolderPicker = true;
             if (dialog.ShowDialog() == CommonFileDialogResult.Ok)
             {
                 //MessageBox.Show("You selected: " + dialog.FileName);
                 selectedpath = dialog.FileName;
                //saveImage(selectedpath);

                if(videoSource != null)
                if (videoSource.IsRunning)
                    saveImage(imageOnClick, dialog.FileName);
            }
     
        }

        void saveImage(Bitmap img, string path)
        {
            // Ayrıca nereye kaydedileceğini seçmesi için path girdim fakat içeriye path yazıp formatını düzeltince "generic gdi+ error" hatası veriyor
            string saveto = path.Replace("/",@"\") + @"\" + "IMG-" + DateTime.Now.ToString().Replace("/", "-").Replace(" ", "").Replace(":","-") + ".jpg";
            //MessageBox.Show(saveto);

            

            // MessageBox.Show(path.Replace("/", @"\") + "IMG" + DateTime.Now.ToString().Replace("/","-").Replace(" ","_"));
            try
            {
                img.Save(saveto,System.Drawing.Imaging.ImageFormat.Jpeg);
            }
            catch (Exception ex)
            {
                img = new Bitmap(img);
                img.Save(saveto, System.Drawing.Imaging.ImageFormat.Jpeg); 
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if(videoSource != null)
            if(videoSource.IsRunning)
            videoSource.Stop();

            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        bool isDragging;
        Size offsetWindow;

        private void label1_MouseDown(object sender, MouseEventArgs e)
        {
            offsetWindow = new Size(MousePosition.X - Location.X, MousePosition.Y - Location.Y);
            isDragging = true;
        }

        private void label1_MouseMove(object sender, MouseEventArgs e)
        {
            if(isDragging)
            Location = MousePosition - offsetWindow;
        }

        private void label1_MouseUp(object sender, MouseEventArgs e)
        {
            isDragging = false;
        }
    }

    
}
